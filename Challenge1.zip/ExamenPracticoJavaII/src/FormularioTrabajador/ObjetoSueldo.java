/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FormularioTrabajador;

/**
 *
 * @author Jeniffer
 */
public class ObjetoSueldo {
    
    public static void main(String[] args) {
        
        Trabajador sueldo = new Trabajador ("Jose", 0 , 0);
        
    }
}
