/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FormularioTrabajador;

/**
 *
 * @author Jeniffer
 */
public class Trabajador {
    private String nombre;
    private double sueldobase1;
    private int añosexperiencia;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSueldobase1() {
        return sueldobase1;
    }

    public void setSueldobase1(double sueldobase1) {
        this.sueldobase1 = sueldobase1;
    }

    public int getAñosexperiencia() {
        return añosexperiencia;
    }

    public void setAñosexperiencia(int añosexperiencia) {
        this.añosexperiencia = añosexperiencia;
    }

    public Trabajador(String nombre, double sueldobase1, int añosexperiencia) {
        this.nombre = nombre;
        this.sueldobase1 = sueldobase1;
        this.añosexperiencia = añosexperiencia;
    }

  
    
    
}
