/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio1;

/**
 *
 * @author Jeniffer
 */
public class Objetopersonaejercicio1 {
    
    public static void main(String[] args) {
        
        Persona estudiante = new Persona("Jeniffer", "Quevedo", 27 , "76601892", 54.50);
        
        System.out.println("Nombre: " + estudiante.getNombre());
        System.out.println("Apellidos: " + estudiante.getApellidos());
        System.out.println("Edad: " + estudiante.getEdad());
        System.out.println("Dni: " + estudiante.getDNI());
        System.out.println("Peso: " + estudiante.getPeso());
    }
}
